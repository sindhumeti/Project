from django.apps import AppConfig


class ProfileConfig(AppConfig):
    name = 'Profile'
